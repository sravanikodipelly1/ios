import UIKit

var greeting = "Hello, playground"
print("Hii",10,12.25)
print(greeting)

//string interpolation
//   \(variableName)
var language = "swift"
print("I dont like \(language)")


var age = 23
print("you are \(age) years old in another \(age) years you will be \(age * 2) ")

var name = "sravani"
var grade = "B"
//HELLO,SRAVANI!
print("Hello,\(name)! your grade is \(grade)")


print("""
Hello.
World!
""")

print("Hello all,\rWelcome to swift programming")


//let is constant
//explicit declaration of the datatype
let welcomeMessage : String = "hello!"
print(welcomeMessage, "all")
print(" welcome to swift prgramming")
    print("FALL 2021")
print("******")
print("hello,\(name) your grade is \(grade)", terminator: " ")
print(" in ios course")



print(" The list of numbers are ")
print(1,2,3,4,5,6)
print("the new pattern is")
print(1,2,3,4,5,6, separator: ",")

//declaration of varaiable
var mobilebrand = "Apple"
mobilebrand = "samsung"
print(mobilebrand)

let pi = 3.14
print(pi)

//explicit declaration of variable
age = age * 2
print(age)

var httpError = (errorCode : 404 , errorMessage : "page not found")
print(httpError)
print(httpError.errorCode , terminator: ": ")
print(httpError.errorMessage)

var pname = ("sravani","kodipelly")
var fname = pname.0
var lname = pname.1
print(fname , terminator: ",")
print(lname)

var origin = (x : 0)






